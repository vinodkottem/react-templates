import Dashboard from "@mui/icons-material/Dashboard";
import NotificationsIcon from "@mui/icons-material/Notifications";
import RouteIcon from "@mui/icons-material/Route";
import ArticleIcon from "@mui/icons-material/Article";
import SettingsIcon from "@mui/icons-material/Settings";

export const routes = [
  { path: "/dashboard", title: "Dashboard", icon: Dashboard },
  { path: "/hello", title: "Hello", icon: NotificationsIcon },
  { path: "/hello1", title: "Routes", icon: RouteIcon },
  { path: "/hello2", title: "Config", icon: ArticleIcon },
  { path: "/hello3", title: "Settings", icon: SettingsIcon },
];
