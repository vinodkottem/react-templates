import React from "react";
import { ListItem, ListItemIcon, ListItemText, List } from "@material-ui/core/";

import { withRouter } from "./hooks";
import { routes } from "./routes";
import { useNavigate } from 'react-router-dom';

const Icon = (props) => {
    const { icon } = props
    const TheIcon = icon
    return <TheIcon {...props} />
  }

export const MenuSettings = withRouter((props) => {
  return (
    <List>
      {routes.map((item, index) => {
        let navigate = useNavigate();
        const handleClick = (path) =>  {
            navigate(path)
          }
       
        return (
            <ListItem
              button
              key={item.title}
              onClick={() => handleClick(item.path)}
            >
              <ListItemIcon>
              <Icon icon={item.icon} />
              </ListItemIcon>
              <ListItemText primary={item.title} />
            </ListItem>
          )
      })}
    </List>
  );
});
