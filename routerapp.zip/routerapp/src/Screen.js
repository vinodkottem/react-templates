import { Body } from "./Body";

export const Screen = (props) => {
  console.log(props);
  return <Body label={props.label} />;
};
